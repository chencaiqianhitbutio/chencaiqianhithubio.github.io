# -*- coding: utf-8 -*-
# 第二篇 第15节 MLP 学习参数的实现和可视化
# 用 numpy 手写一个两层网络（2 -> 10 -> 1），
# 在月牙形数据上训练，把损失曲线、W1 权重、决策边界画出来。
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["SimHei"]   # 让图里能显示中文
plt.rcParams["axes.unicode_minus"] = False

np.random.seed(1)

# ---------- 1. 造数据：两个月牙形的数据团 ----------
n = 200
theta1 = np.linspace(0, np.pi, n)          # 上面那弯月牙
x1 = np.cos(theta1) + np.random.normal(0, 0.12, n)
y1 = np.sin(theta1) + np.random.normal(0, 0.12, n)
theta2 = np.linspace(0, np.pi, n)          # 下面那弯月牙
x2 = 1 - np.cos(theta2) + np.random.normal(0, 0.12, n)
y2 = 0.5 - np.sin(theta2) + np.random.normal(0, 0.12, n)

X = np.vstack([np.column_stack([x1, y1]),
               np.column_stack([x2, y2])])  # 形状 (400, 2)
T = np.concatenate([np.zeros(n), np.ones(n)]).reshape(-1, 1)  # 标签 0 / 1

# ---------- 2. 网络参数：输入2个 -> 隐藏10个 -> 输出1个 ----------
H = 10
W1 = np.random.normal(0, 0.5, (2, H))
b1 = np.zeros((1, H))
W2 = np.random.normal(0, 0.5, (H, 1))
b2 = np.zeros((1, 1))
lr = 0.5        # 学习率
epochs = 3000   # 训练轮数

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

def forward(X):
    z1 = X @ W1 + b1
    a1 = np.tanh(z1)
    z2 = a1 @ W2 + b2
    a2 = sigmoid(z2)
    return a1, a2

def bce_loss(p, t):
    eps = 1e-8
    return -np.mean(t * np.log(p + eps) + (1 - t) * np.log(1 - p + eps))

# ---------- 3. 训练：手推梯度，每轮更新一次 ----------
losses = []
for epoch in range(epochs):
    a1, a2 = forward(X)
    losses.append(bce_loss(a2, T))

    # 反向传播
    dz2 = a2 - T                        # sigmoid + BCE 求导后正好是这个
    dW2 = a1.T @ dz2 / len(X)
    db2 = dz2.mean(axis=0, keepdims=True)
    dz1 = (dz2 @ W2.T) * (1 - a1 ** 2)  # tanh 的导数是 1 - a^2
    dW1 = X.T @ dz1 / len(X)
    db1 = dz1.mean(axis=0, keepdims=True)

    W1 -= lr * dW1
    b1 -= lr * db1
    W2 -= lr * dW2
    b2 -= lr * db2

    if (epoch + 1) % 500 == 0:
        print(f"第 {epoch+1} 轮  loss = {losses[-1]:.4f}")

# ---------- 4. 三张图 ----------
# 图1：损失曲线
plt.figure(figsize=(7, 4.5))
plt.plot(losses, color="#6c5ce7")
plt.xlabel("训练轮数")
plt.ylabel("损失值")
plt.title("训练损失曲线")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig("images/loss.png", dpi=120)
plt.close()

# 图2：W1 权重热力图（2个输入 x 10个隐藏神经元）
plt.figure(figsize=(7, 4.5))
plt.imshow(W1.T, cmap="coolwarm", aspect="auto")
plt.colorbar(label="权重值")
plt.xticks([0, 1], ["输入 x1", "输入 x2"])
plt.yticks(range(H), [f"隐藏神经元 {i+1}" for i in range(H)])
plt.title("W1 权重可视化")
for i in range(2):
    for j in range(H):
        plt.text(i, j, f"{W1[i][j]:.2f}", ha="center", va="center",
                 color="white" if abs(W1[i][j]) > 0.8 else "black", fontsize=8)
plt.tight_layout()
plt.savefig("images/weight_W1.png", dpi=120)
plt.close()

# 图3：决策边界
xx, yy = np.meshgrid(np.linspace(-1.5, 2.5, 300), np.linspace(-1.2, 1.8, 300))
grid = np.column_stack([xx.ravel(), yy.ravel()])
_, pp = forward(grid)
zz = pp.reshape(xx.shape)
plt.figure(figsize=(7, 5.5))
plt.contourf(xx, yy, zz, levels=[0, 0.5, 1], colors=["#dfe6e9", "#ffeaa7"], alpha=0.8)
plt.contour(xx, yy, zz, levels=[0.5], colors="#d63031", linewidths=1.5)
plt.scatter(X[:n, 0], X[:n, 1], c="#0984e3", s=18, label="类别 0")
plt.scatter(X[n:, 0], X[n:, 1], c="#00b894", s=18, label="类别 1")
plt.xlabel("x1")
plt.ylabel("x2")
plt.title("MLP 学到的决策边界")
plt.legend(loc="upper right")
plt.tight_layout()
plt.savefig("images/decision_boundary.png", dpi=120)
plt.close()

# 顺便算一下准确率
_, pred = forward(X)
acc = ((pred > 0.5) == (T == 1)).mean()
print(f"最终 loss = {losses[-1]:.4f}，训练集准确率 = {acc:.1%}")
